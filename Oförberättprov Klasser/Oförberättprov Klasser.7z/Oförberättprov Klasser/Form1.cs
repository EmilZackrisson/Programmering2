﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oförberättprov_Klasser
{
    public partial class Form1 : Form
    {
        List<Planet> lista = new List<Planet>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRemoveAll_Click(object sender, EventArgs e)
        {
            lista.Clear();
            uppdateraLista(lista);
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            try
            {
                bool beboelig;
                if (rdbBeboeligJa.Checked)
                {
                    beboelig = true;
                }
                else if (rdbBeboeligNej.Checked)
                {
                    beboelig = false;
                }
                else
                {
                    MessageBox.Show("Du måste säga om den är beboelig eller inte.");
                    return;
                }
                Planet planet = new Planet(
                    tbxRegNamn.Text,
                    Convert.ToInt32(tbxRegVolym.Text),
                    Convert.ToDouble(tbxRegRadie.Text),
                    beboelig
                );
                lista.Add(planet);
                uppdateraLista(lista);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }


        }

        void uppdateraLista(List<Planet> lista)
        {
            listBox1.Items.Clear();
            for (int i = 0; i < lista.Count; i++)
            {
                listBox1.Items.Add(lista[i].ToString());
            }
            listBox1.Update();
        }

        private void btnRensaReg_Click(object sender, EventArgs e)
        {
            tbxRegNamn.Clear();
            tbxRegRadie.Clear();
            tbxRegVolym.Clear();
            rdbBeboeligJa.Checked = false;
            rdbBeboeligNej.Checked = false;
        }

        private void btnUppdatera_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedIndex = listBox1.SelectedIndex;

                bool beboelig;
                if (rdbBeboeligUppdateraJa.Checked)
                {
                    beboelig = true;
                }
                else if (rdbBeboeligUppdateraNej.Checked)
                {
                    beboelig = false;
                }
                else
                {
                    MessageBox.Show("Du måste säga om den är beboelig eller inte.");
                    return;
                }
                Planet planet = new Planet(
                    tbxUppdateraNamn.Text,
                    Convert.ToInt32(tbxUppdateraVolym.Text),
                    Convert.ToDouble(tbxUppdateraRadie.Text),
                    beboelig
                );
                lista.RemoveAt(selectedIndex);
                lista.Add(planet);
                uppdateraLista(lista);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

        }

        private void btnRemoveSel_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBox1.SelectedIndex;
                lista.RemoveAt(index);
                uppdateraLista(lista);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
