﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objekt
{
    internal class Person
    {

        public string förnamn;
        public string efternamn;
        public string telefon;

    }
}
