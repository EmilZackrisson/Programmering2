﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSök_Click(object sender, EventArgs e)
        {
            string söktext = textBox1.Text;
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Programmering 2\C#\SQL\Kundregister.mdf;Integrated Security=True";
            string query = "SELECT Namn FROM [Table] WHERE Id=" + int.Parse(söktext);

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                lbxResultat.Items.Clear();
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string namn = reader.GetString(0);
                        lbxResultat.Items.Add(namn);
                    }
                    reader.Close();
                }
            }
        }
    }
}
